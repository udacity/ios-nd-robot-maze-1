//
//  ControlCenter.swift
//  Maze
//
//  Created by Jarrod Parkes on 8/14/15.
//  Copyright © 2015 Udacity, Inc. All rights reserved.
//

class ControlCenter {
    
    
    
    
    func moveSimpleRobot(robot: SimpleRobot) {
        
        //robot.moveUp()
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    robot.moveLeft()
//    robot.moveUp()
//    robot.moveLeft()
//    robot.moveDown()
//    robot.moveDown()
//    robot.moveDown()
//    robot.moveLeft()
//    robot.moveUp()
//    robot.moveUp()
//    robot.moveUp()
    
    
    
    func moveComplexRobot(robot: ComplexRobot) {
//        robot.rotateLeft()
//        robot.move()
//        robot.rotateRight()
//        robot.move()
//        robot.rotateLeft()
//        robot.move()
//        robot.rotateLeft()
//        robot.move(3)
//        robot.rotateRight()
//        robot.move()
//        robot.rotateRight()
//        robot.move(3)
    }
}