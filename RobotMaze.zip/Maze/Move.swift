//
//  Move.swift
//  Maze
//
//  Created by Jarrod Parkes on 8/14/15.
//  Copyright © 2015 Udacity, Inc. All rights reserved.
//

// MARK: - Move

struct Move {
    let dx: Int
    let dy: Int
}